import os, sqlite3, secrets
from functools import wraps
from flask import Flask, g, render_template, request, redirect, url_for, session, flash, abort
from werkzeug.security import generate_password_hash, check_password_hash
import requests

APP_SECRET = os.environ.get("CFGRADER_SECRET_KEY")
ADMIN_USERNAME = os.environ.get("CFGRADER_ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.environ.get("CFGRADER_ADMIN_PASSWORD")
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "")
DATABASE = os.environ.get("CFGRADER_DATABASE", "cfgrader.sqlite3")

if not APP_SECRET or not ADMIN_PASSWORD:
    raise RuntimeError("Set CFGRADER_SECRET_KEY and CFGRADER_ADMIN_PASSWORD environment variables before starting.")

app = Flask(__name__)
app.secret_key = APP_SECRET
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1",
                  MAX_CONTENT_LENGTH=1_000_000)

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(exc):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()

def init_db():
    conn = sqlite3.connect(DATABASE)
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL, balance INTEGER NOT NULL DEFAULT 0,
      is_admin INTEGER NOT NULL DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS skins(
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT NOT NULL,
      price INTEGER NOT NULL CHECK(price > 0 AND price <= 15000), icon TEXT NOT NULL DEFAULT '✦',
      active INTEGER NOT NULL DEFAULT 1);
    CREATE TABLE IF NOT EXISTS requests(
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id),
      telegram_username TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount > 0 AND amount <= 15000),
      status TEXT NOT NULL DEFAULT 'pending', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS transactions(
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id),
      admin_id INTEGER REFERENCES users(id), amount INTEGER NOT NULL, kind TEXT NOT NULL,
      note TEXT NOT NULL DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS inventory(
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id),
      skin_id INTEGER NOT NULL REFERENCES skins(id), acquired_at TEXT DEFAULT CURRENT_TIMESTAMP);
    """)
    count = conn.execute("SELECT COUNT(*) FROM skins").fetchone()[0]
    if count == 0:
        # Demo items only. Replace with verified CountryFlame data before public launch.
        conn.executemany("INSERT INTO skins(name,category,price,icon) VALUES(?,?,?,?)", [
          ("AKR — Ember","Автомат",1200,"⚔"), ("M4 — Nightfall","Винтовка",2400,"✦"),
          ("AWM — Frostbite","Снайперская винтовка",4800,"❄"), ("Knife — Violet","Нож",8500,"◈"),
          ("Gloves — Phantom","Перчатки",11200,"✧"), ("Rifle — Solar","Винтовка",15000,"☼")])
    row = conn.execute("SELECT id FROM users WHERE username=?", (ADMIN_USERNAME,)).fetchone()
    if row is None:
        conn.execute("INSERT INTO users(username,password_hash,is_admin) VALUES(?,?,1)",
                     (ADMIN_USERNAME, generate_password_hash(ADMIN_PASSWORD)))
    conn.commit()
    conn.close()

def current_user():
    uid = session.get("user_id")
    if not uid: return None
    return db().execute("SELECT id,username,balance,is_admin FROM users WHERE id=?", (uid,)).fetchone()

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not current_user():
            flash("Сначала войди в аккаунт.", "error")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapped

def admin_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        user = current_user()
        if not user or not user["is_admin"]:
            abort(403)
        return fn(*args, **kwargs)
    return wrapped

def csrf_token():
    if "_csrf" not in session: session["_csrf"] = secrets.token_urlsafe(32)
    return session["_csrf"]
app.jinja_env.globals["csrf_token"] = csrf_token

@app.before_request
def protect_posts():
    if request.method == "POST":
        sent = request.form.get("_csrf", "")
        expected = session.get("_csrf", "")
        if not expected or not secrets.compare_digest(sent, expected):
            abort(400, "Invalid CSRF token")

def telegram_notify(message):
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        app.logger.warning("Telegram not configured; deposit request notification not sent.")
        return False
    try:
        response = requests.post(
            f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage",
            json={"chat_id": TELEGRAM_CHAT_ID, "text": message},
            timeout=8)
        response.raise_for_status()
        return response.json().get("ok", False)
    except requests.RequestException:
        app.logger.exception("Telegram notification failed")
        return False

@app.route("/")
def index():
    user = current_user()
    skins = db().execute("SELECT * FROM skins WHERE active=1 AND price<=15000 ORDER BY price").fetchall()
    return render_template("index.html", user=user, skins=skins)

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","")
        if len(username) < 3 or len(username) > 24 or not username.replace("_","").isalnum():
            flash("Логин: 3–24 символа, латинские буквы, цифры или _.","error")
        elif len(password) < 10:
            flash("Пароль должен содержать минимум 10 символов.","error")
        else:
            try:
                db().execute("INSERT INTO users(username,password_hash) VALUES(?,?)",
                             (username, generate_password_hash(password)))
                db().commit()
                flash("Аккаунт создан. Теперь войди.","success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("Этот логин уже занят.","error")
    return render_template("auth.html", mode="register", user=current_user())

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","")
        row = db().execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if row and check_password_hash(row["password_hash"], password):
            session.clear()
            session["user_id"] = row["id"]
            session["_csrf"] = secrets.token_urlsafe(32)
            return redirect(url_for("index"))
        flash("Неверный логин или пароль.","error")
    return render_template("auth.html", mode="login", user=current_user())

@app.post("/logout")
@login_required
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.post("/deposit")
@login_required
def deposit():
    try: amount = int(request.form.get("amount","0"))
    except ValueError: amount = 0
    tg = request.form.get("telegram_username","").strip().lstrip("@")
    if not 1 <= amount <= 15000 or not tg or len(tg) > 64:
        flash("Укажи сумму от 1 до 15 000 CF и Telegram username.","error")
        return redirect(url_for("index"))
    user = current_user()
    cur = db().execute("INSERT INTO requests(user_id,telegram_username,amount) VALUES(?,?,?)",
                       (user["id"], "@"+tg, amount))
    db().commit()
    request_id = cur.lastrowid
    sent = telegram_notify(
        f"💰 CFGRADER — новая заявка #{request_id}\\n"
        f"Игрок: {user['username']} (ID {user['id']})\\n"
        f"Telegram: @{tg}\\nСумма: {amount:,} CF\\n"
        f"Проверь оплату вручную и обработай заявку в админ-панели.".replace(",", " "))
    flash(f"Заявка #{request_id} сохранена." + ("" if sent else " Уведомление Telegram пока не настроено; заявка всё равно сохранена."), "success")
    return redirect(url_for("index"))

@app.post("/buy/<int:skin_id>")
@login_required
def buy(skin_id):
    conn = db()
    try:
        conn.execute("BEGIN IMMEDIATE")
        user = conn.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
        skin = conn.execute("SELECT * FROM skins WHERE id=? AND active=1 AND price<=15000", (skin_id,)).fetchone()
        if not skin: raise ValueError("Скин не найден.")
        if user["balance"] < skin["price"]: raise ValueError("Недостаточно CF.")
        conn.execute("UPDATE users SET balance=balance-? WHERE id=?", (skin["price"], user["id"]))
        conn.execute("INSERT INTO inventory(user_id,skin_id) VALUES(?,?)", (user["id"], skin_id))
        conn.execute("INSERT INTO transactions(user_id,amount,kind,note) VALUES(?,?,?,?)",
                     (user["id"], -skin["price"], "purchase", f"Покупка: {skin['name']}"))
        conn.commit()
        flash("Покупка выполнена.","success")
    except ValueError as e:
        conn.rollback(); flash(str(e),"error")
    except Exception:
        conn.rollback(); app.logger.exception("Purchase failed"); flash("Не удалось выполнить покупку.","error")
    return redirect(url_for("index"))

@app.route("/admin", methods=["GET","POST"])
@login_required
@admin_required
def admin():
    conn = db()
    if request.method == "POST":
        action = request.form.get("action")
        try:
            conn.execute("BEGIN IMMEDIATE")
            if action == "credit":
                uid = int(request.form.get("user_id","0")); amount = int(request.form.get("amount","0"))
                if not 1 <= amount <= 15000: raise ValueError("Начисление должно быть от 1 до 15 000 CF.")
                target = conn.execute("SELECT id FROM users WHERE id=?", (uid,)).fetchone()
                if not target: raise ValueError("Игрок с таким ID не найден.")
                conn.execute("UPDATE users SET balance=balance+? WHERE id=?", (amount,uid))
                conn.execute("INSERT INTO transactions(user_id,admin_id,amount,kind,note) VALUES(?,?,?,?,?)",
                             (uid,session["user_id"],amount,"admin_credit",f"Ручное начисление администратором #{session['user_id']}"))
                conn.commit(); flash(f"Начислено {amount} CF игроку ID {uid}.","success")
            elif action == "request":
                rid = int(request.form.get("request_id","0"))
                req = conn.execute("SELECT * FROM requests WHERE id=?", (rid,)).fetchone()
                if not req or req["status"] != "pending": raise ValueError("Заявка не найдена или уже обработана.")
                decision = request.form.get("decision")
                if decision == "paid":
                    conn.execute("UPDATE users SET balance=balance+? WHERE id=?", (req["amount"],req["user_id"]))
                    conn.execute("INSERT INTO transactions(user_id,admin_id,amount,kind,note) VALUES(?,?,?,?,?)",
                                 (req["user_id"],session["user_id"],req["amount"],"deposit",f"Заявка #{rid} подтверждена"))
                    conn.execute("UPDATE requests SET status='credited' WHERE id=?", (rid,))
                    conn.commit(); flash(f"Заявка #{rid} подтверждена, баланс начислен.","success")
                elif decision == "reject":
                    conn.execute("UPDATE requests SET status='rejected' WHERE id=?", (rid,))
                    conn.commit(); flash(f"Заявка #{rid} отклонена.","success")
                else: raise ValueError("Неизвестное действие.")
            else: raise ValueError("Неизвестное действие.")
        except (ValueError, sqlite3.Error) as e:
            conn.rollback(); flash(str(e),"error")
        return redirect(url_for("admin"))
    users = conn.execute("SELECT id,username,balance,created_at FROM users ORDER BY id DESC LIMIT 100").fetchall()
    reqs = conn.execute("""SELECT r.*,u.username FROM requests r JOIN users u ON u.id=r.user_id
                           ORDER BY CASE status WHEN 'pending' THEN 0 ELSE 1 END, r.id DESC LIMIT 100""").fetchall()
    txs = conn.execute("""SELECT t.*,u.username, a.username AS admin_name FROM transactions t
                          JOIN users u ON u.id=t.user_id LEFT JOIN users a ON a.id=t.admin_id
                          ORDER BY t.id DESC LIMIT 50""").fetchall()
    return render_template("admin.html", user=current_user(), users=users, requests=reqs, transactions=txs)

@app.errorhandler(403)
def forbidden(e):
    return render_template("error.html", code=403, message="Доступ только для администратора.", user=current_user()), 403
@app.errorhandler(400)
def bad_request(e):
    return render_template("error.html", code=400, message="Запрос не прошёл проверку безопасности.", user=current_user()), 400

init_db()
if __name__ == "__main__":
    # Local development only. Use a production WSGI server in deployment.
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT","5000")), debug=False)
