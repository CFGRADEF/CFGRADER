# CFGRADER starter

Starter backend for a CountryFlame-themed skin upgrader. This is a foundation, **not yet a complete public-ready website**: the existing visual prototype must be connected to these API endpoints, and the sample skin data must be replaced by verified CountryFlame data.

## What is included

- Express API
- SQLite database for users, balances, skins, inventory, deposit requests, transactions and upgrade history
- Password hashing with bcrypt
- Server-side sessions and login rate limits
- Admin bootstrap from environment variables
- Manual deposit approval with a database transaction and duplicate-processing protection
- Manual admin credit by user ID
- Telegram notification for new deposit requests (Bot API)
- Server-side 1–15,000 CF validation for catalog item prices and deposit request amounts

## Run locally

1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Fill `SESSION_SECRET`, `ADMIN_USERNAME`, `ADMIN_PASSWORD`.
4. Optionally create a Telegram bot with `@BotFather`, then fill `TELEGRAM_BOT_TOKEN` and `TELEGRAM_ADMIN_CHAT_ID`.
5. Run:

   ```bash
   npm install
   npm start
   ```

6. Open `http://localhost:3000/api/health`.

The `data/` directory is created automatically. Back it up securely.

## Telegram setup

1. Open Telegram and message `@BotFather`.
2. Send `/newbot` and follow its instructions.
3. Put the token in `.env` as `TELEGRAM_BOT_TOKEN`.
4. To get your private chat ID, message your bot once, then use Telegram's `getUpdates` endpoint privately or use a trusted bot/chat-ID utility. Do not post the token publicly.
5. Set `TELEGRAM_ADMIN_CHAT_ID` in `.env` and restart the server.

The bot token is a password. Anyone who obtains it may control your bot.

## API endpoints

- `POST /api/auth/register` `{ "username": "...", "password": "..." }`
- `POST /api/auth/login` `{ "username": "...", "password": "..." }`
- `POST /api/auth/logout`
- `GET /api/me`
- `GET /api/skins`
- `GET /api/transactions` (login required)
- `POST /api/deposits` `{ "amount": 500, "telegramUsername": "username" }` (login required)
- `GET /api/admin/overview` (admin only)
- `POST /api/admin/deposits/:id/credit` (admin only; credits exactly once)
- `POST /api/admin/users/:id/credit` `{ "amount": 500 }` (admin only)
- `POST /api/admin/skins` `{ "name": "...", "category": "...", "price": 500, "imageUrl": "https://..." }` (admin only)

## Before public launch — important

- **Do not treat the sample items as real CountryFlame skins.** Replace them only with verified item names, prices and permitted images.
- Connect a real frontend to the API. The prototype HTML is UI only and its demo balance must not be used as a real balance.
- Add CSRF protection and review cookie/session settings before production.
- SQLite works best on a persistent disk. If deploying to a host with ephemeral filesystems, user data can disappear on redeploy/restart. Use a persistent disk or migrate to managed PostgreSQL.
- Configure HTTPS, backups, monitoring and secret environment variables.
- Have the game/service terms and any applicable rules reviewed before accepting money.
- Do not promise real game item delivery unless an authorized CountryFlame integration actually supports it.
