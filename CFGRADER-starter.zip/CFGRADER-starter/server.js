require("dotenv").config();
const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const TelegramBot = require("node-telegram-bot-api");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProd = process.env.NODE_ENV === "production";
const sessionSecret = process.env.SESSION_SECRET || "";
if (isProd && sessionSecret.length < 32) {
  throw new Error("SESSION_SECRET must be a random string of at least 32 characters in production.");
}
if (!process.env.ADMIN_USERNAME || !process.env.ADMIN_PASSWORD) {
  console.warn("Set ADMIN_USERNAME and ADMIN_PASSWORD in .env before using admin features.");
}
fs.mkdirSync(path.join(__dirname, "data"), { recursive: true });
const db = new Database(path.join(__dirname, "data", "cfgrader.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  balance INTEGER NOT NULL DEFAULT 0 CHECK(balance >= 0),
  is_admin INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS skins (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'Skin',
  price INTEGER NOT NULL CHECK(price > 0 AND price <= 15000),
  image_url TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS deposit_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  amount INTEGER NOT NULL CHECK(amount > 0 AND amount <= 15000),
  telegram_username TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','paid','rejected')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  processed_at TEXT,
  processed_by INTEGER REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  admin_id INTEGER REFERENCES users(id),
  amount INTEGER NOT NULL,
  kind TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS inventory (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  skin_id INTEGER NOT NULL REFERENCES skins(id),
  acquired_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS upgrades (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  source_skin_id INTEGER NOT NULL REFERENCES skins(id),
  target_skin_id INTEGER NOT NULL REFERENCES skins(id),
  won INTEGER NOT NULL,
  chance REAL NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const count = db.prepare("SELECT COUNT(*) AS n FROM skins").get().n;
if (!count) {
  // Clearly labeled sample data. Replace with verified CountryFlame item data before public launch.
  const insert = db.prepare("INSERT INTO skins(name,category,price,image_url) VALUES(?,?,?,?)");
  const sample = [
    ["DEMO — Ember Rifle","Rifle",1200,""],
    ["DEMO — Nightfall","Rifle",2400,""],
    ["DEMO — Frostbite","Sniper",4800,""],
    ["DEMO — Violet Knife","Knife",8500,""],
    ["DEMO — Phantom Gloves","Gloves",11200,""],
    ["DEMO — Solar Rifle","Rifle",15000,""]
  ];
  const tx = db.transaction(rows => rows.forEach(x => insert.run(...x)));
  tx(sample);
}

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));
app.use(session({
  name: "cfgrader.sid",
  secret: sessionSecret || "development-only-secret-change-me",
  resave: false,
  saveUninitialized: false,
  store: new SQLiteStore({ db: "sessions.sqlite", dir: path.join(__dirname, "data") }),
  cookie: { httpOnly: true, sameSite: "lax", secure: isProd, maxAge: 1000 * 60 * 60 * 24 * 7 }
}));
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false });
const requestLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 8, standardHeaders: true, legacyHeaders: false });

const userView = u => ({ id: u.id, username: u.username, balance: u.balance, isAdmin: !!u.is_admin });
function currentUser(req) {
  if (!req.session.userId) return null;
  return db.prepare("SELECT id,username,balance,is_admin FROM users WHERE id=?").get(req.session.userId) || null;
}
function requireAuth(req,res,next) {
  const u = currentUser(req);
  if (!u) return res.status(401).json({ error: "Сначала войдите в аккаунт." });
  req.user = u; next();
}
function requireAdmin(req,res,next) {
  const u = currentUser(req);
  if (!u || !u.is_admin) return res.status(403).json({ error: "Доступ только для администратора." });
  req.user = u; next();
}
async function notifyAdmin(text) {
  const token = process.env.TELEGRAM_BOT_TOKEN, chatId = process.env.TELEGRAM_ADMIN_CHAT_ID;
  if (!token || !chatId) {
    console.warn("Telegram notification skipped: configure TELEGRAM_BOT_TOKEN and TELEGRAM_ADMIN_CHAT_ID.");
    return;
  }
  try {
    const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text })
    });
    if (!response.ok) console.error("Telegram notification failed:", response.status);
  } catch (e) { console.error("Telegram notification error:", e.message); }
}

// Bootstrap the admin once from environment variables. Existing accounts are never silently changed.
(async () => {
  if (!process.env.ADMIN_USERNAME || !process.env.ADMIN_PASSWORD) return;
  const existing = db.prepare("SELECT id FROM users WHERE username=?").get(process.env.ADMIN_USERNAME);
  if (!existing) {
    const hash = await bcrypt.hash(process.env.ADMIN_PASSWORD, 12);
    db.prepare("INSERT INTO users(username,password_hash,balance,is_admin) VALUES(?,?,0,1)")
      .run(process.env.ADMIN_USERNAME, hash);
    console.log("Initial admin created from environment configuration.");
  } else {
    db.prepare("UPDATE users SET is_admin=1 WHERE id=?").run(existing.id);
  }
})().catch(err => { console.error("Admin bootstrap failed:", err); process.exit(1); });

app.get("/api/health", (req,res) => res.json({ ok: true, app: "CFGRADER", mode: "starter" }));
app.post("/api/auth/register", authLimiter, async (req,res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  if (!/^[a-zA-Z0-9_]{3,24}$/.test(username)) return res.status(400).json({error:"Логин: 3–24 символа, латиница, цифры и _."});
  if (password.length < 10 || password.length > 128) return res.status(400).json({error:"Пароль должен быть длиной 10–128 символов."});
  const hash = await bcrypt.hash(password, 12);
  try {
    const result = db.prepare("INSERT INTO users(username,password_hash) VALUES(?,?)").run(username,hash);
    req.session.userId = Number(result.lastInsertRowid);
    res.status(201).json({ user: userView(currentUser(req)) });
  } catch { res.status(409).json({error:"Этот логин уже занят."}); }
});
app.post("/api/auth/login", authLimiter, async (req,res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  const u = db.prepare("SELECT * FROM users WHERE username=? COLLATE NOCASE").get(username);
  if (!u || !(await bcrypt.compare(password,u.password_hash))) return res.status(401).json({error:"Неверный логин или пароль."});
  req.session.regenerate(err => {
    if (err) return res.status(500).json({error:"Не удалось создать сессию."});
    req.session.userId = u.id;
    req.session.save(err2 => err2 ? res.status(500).json({error:"Не удалось сохранить сессию."}) : res.json({user:userView(currentUser(req))}));
  });
});
app.post("/api/auth/logout", (req,res) => req.session.destroy(() => { res.clearCookie("cfgrader.sid"); res.json({ok:true}); }));
app.get("/api/me", requireAuth, (req,res) => res.json({user:userView(req.user)}));
app.get("/api/skins", (req,res) => res.json({skins:db.prepare("SELECT id,name,category,price,image_url FROM skins WHERE active=1 AND price<=15000 ORDER BY price").all()}));
app.get("/api/transactions", requireAuth, (req,res) => res.json({transactions:db.prepare("SELECT amount,kind,note,created_at FROM transactions WHERE user_id=? ORDER BY id DESC LIMIT 100").all(req.user.id)}));

app.post("/api/deposits", requireAuth, requestLimiter, async (req,res) => {
  const amount = Number(req.body.amount);
  const telegram = String(req.body.telegramUsername || "").trim().replace(/^@/,"");
  if (!Number.isInteger(amount) || amount < 1 || amount > 15000) return res.status(400).json({error:"Сумма должна быть от 1 до 15 000 CF."});
  if (!/^[a-zA-Z0-9_]{5,32}$/.test(telegram)) return res.status(400).json({error:"Укажи корректный Telegram username."});
  const result = db.prepare("INSERT INTO deposit_requests(user_id,amount,telegram_username) VALUES(?,?,?)").run(req.user.id,amount,telegram);
  await notifyAdmin(`🟣 Новая заявка CFGRADER #${result.lastInsertRowid}\nИгрок: ${req.user.username} (ID ${req.user.id})\nTelegram: @${telegram}\nСумма: ${amount} CF\nСтатус: ожидает проверки`);
  res.status(201).json({request:{id:Number(result.lastInsertRowid),amount,status:"pending"}});
});

app.get("/api/admin/overview", requireAdmin, (req,res) => {
  const requests = db.prepare(`SELECT d.id,d.user_id,u.username,d.amount,d.telegram_username,d.status,d.created_at
    FROM deposit_requests d JOIN users u ON u.id=d.user_id ORDER BY d.id DESC LIMIT 100`).all();
  res.json({requests,skins:db.prepare("SELECT * FROM skins ORDER BY id").all()});
});
app.post("/api/admin/deposits/:id/credit", requireAdmin, (req,res) => {
  const id = Number(req.params.id);
  const run = db.transaction(() => {
    const d = db.prepare("SELECT * FROM deposit_requests WHERE id=?").get(id);
    if (!d) throw new Error("Заявка не найдена.");
    if (d.status !== "pending") throw new Error("Эта заявка уже обработана.");
    db.prepare("UPDATE users SET balance=balance+? WHERE id=?").run(d.amount,d.user_id);
    db.prepare("INSERT INTO transactions(user_id,admin_id,amount,kind,note) VALUES(?,?,?,'deposit',?)")
      .run(d.user_id,req.user.id,d.amount,`Пополнение по заявке #${id}`);
    db.prepare("UPDATE deposit_requests SET status='paid',processed_at=CURRENT_TIMESTAMP,processed_by=? WHERE id=?").run(req.user.id,id);
    return db.prepare("SELECT id,username,balance FROM users WHERE id=?").get(d.user_id);
  });
  try {
    const user = run();
    notifyAdmin(`✅ Заявка #${id} обработана администратором ${req.user.username}. Начислено ${user.balance} CF всего на аккаунте ${user.username} (ID ${user.id}).`);
    res.json({ok:true,user});
  } catch(e) { res.status(400).json({error:e.message}); }
});
app.post("/api/admin/users/:id/credit", requireAdmin, (req,res) => {
  const userId = Number(req.params.id), amount = Number(req.body.amount);
  if (!Number.isInteger(userId) || userId < 1 || !Number.isInteger(amount) || amount < 1 || amount > 15000) {
    return res.status(400).json({error:"Проверь ID пользователя и сумму (1–15 000 CF)."});
  }
  const run = db.transaction(() => {
    const u = db.prepare("SELECT id,username,balance FROM users WHERE id=?").get(userId);
    if (!u) throw new Error("Игрок не найден.");
    db.prepare("UPDATE users SET balance=balance+? WHERE id=?").run(amount,userId);
    db.prepare("INSERT INTO transactions(user_id,admin_id,amount,kind,note) VALUES(?,?,?,'admin_credit',?)")
      .run(userId,req.user.id,amount,`Ручное начисление администратором ${req.user.username}`);
    return db.prepare("SELECT id,username,balance FROM users WHERE id=?").get(userId);
  });
  try { res.json({ok:true,user:run()}); } catch(e) { res.status(400).json({error:e.message}); }
});
app.post("/api/admin/skins", requireAdmin, (req,res) => {
  const name = String(req.body.name || "").trim(), category = String(req.body.category || "Skin").trim();
  const price = Number(req.body.price), imageUrl = String(req.body.imageUrl || "").trim();
  if (!name || name.length>100 || !Number.isInteger(price) || price<1 || price>15000) return res.status(400).json({error:"Название обязательно, цена — от 1 до 15 000 CF."});
  if (imageUrl && !/^https:\/\/\S+$/i.test(imageUrl)) return res.status(400).json({error:"Изображение должно использовать HTTPS URL."});
  const result = db.prepare("INSERT INTO skins(name,category,price,image_url) VALUES(?,?,?,?)").run(name,category.slice(0,50),price,imageUrl);
  res.status(201).json({ok:true,id:Number(result.lastInsertRowid)});
});
app.use(express.static(path.join(__dirname,"public")));
app.use((err,req,res,next) => { console.error(err); res.status(500).json({error:"Внутренняя ошибка сервера."}); });
app.listen(PORT, () => console.log(`CFGRADER starter listening on http://localhost:${PORT}`));
